# Spring Boot Login & Registration System

A simple Spring Boot web application demonstrating **user registration, login, and home page access** with basic HTML/CSS UI.

---

## 📌 Features

- **User Registration**: New users can register with a username and password.
- **Registration Success Page**: Confirms registration and links to login.
- **User Login**: Registered users can log in.
- **Home Page**: Access granted only after successful login.
- **Basic UI**: Clean, responsive HTML/CSS pages (`register.html`, `login.html`, `success.html`, `home.html`).

---

## 💻 Technologies Used

- **Java 17+**
- **Spring Boot**
- **Spring MVC**
- **JDBC Template**
- **MySQL**
- **HTML / CSS**
- **Thymeleaf** (for templates)

---
